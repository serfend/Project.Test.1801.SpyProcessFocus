﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Inst.Util.Output
{
	public partial class OptShowInner : Form
	{
		public OptShowInner()
		{
			InitializeComponent();
		}
	}
}
