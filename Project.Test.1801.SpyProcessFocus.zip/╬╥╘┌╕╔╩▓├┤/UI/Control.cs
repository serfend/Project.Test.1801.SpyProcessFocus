﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace Time时间记录器.UI
{
	public class Control : System.Windows.Forms.Control
	{
		public Control()
		{
			refreshBounds= new RefreshBounds(更新);
		}
		protected override void OnResize(EventArgs e)
		{
			this.Invalidate();
			base.OnResize(e);
		}

		private Rectangle showPos, hidePos;
		private Rectangle targetPos;
		protected Rectangle TargetPos { get => targetPos; set => targetPos = value; }
		protected Rectangle ShowPos { get => showPos; set => showPos = value; }
		protected Rectangle HidePos { get => hidePos; set => hidePos = value; }

		protected enum MovingStyle
		{
			none,vertical,horizon,both
		}
		protected MovingStyle movingStyle=MovingStyle.both;
		protected float MovingSpeed=0.2f;
		public virtual void 显示()
		{
			base.Show();
		}
		public virtual void 隐藏()
		{
			base.Hide();
		}
		private delegate void RefreshBounds(bool show);
		private Rectangle dBounds;
		public Rectangle DBounds
		{
			get => dBounds;
			set
			{
				dBounds = value;
				//SetBounds((int)(DBounds.X - DBounds.Width * 0.1), (int)(DBounds.Y - DBounds.Height * 0.1), (int)(DBounds.Width * 1.2), (int)(DBounds.Height * 1.2));
				SetBounds(DBounds.X, DBounds.Y, DBounds.Width, DBounds.Height);
			}
		}
		RefreshBounds refreshBounds;
		public virtual void 更新(bool show)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(refreshBounds,new object []{ show});
			}
			else
			{
				var newPos = show ? this.ShowPos : this.HidePos;
				DBounds = new Rectangle((int)(DBounds.X * MovingSpeed + newPos.X * (1 - MovingSpeed)),(int)(DBounds.Y * MovingSpeed + newPos.Y * (1 - MovingSpeed)), (int)(DBounds.Width * MovingSpeed + newPos.Width * (1 - MovingSpeed)), (int)(DBounds.Height * MovingSpeed + newPos.Height * (1 - MovingSpeed)));
			}

		}
	}
}
